#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include "util.h"
// #include <makeargv.h>

typedef struct Candidate {
  char name[1024];
  int numOfVotes;
  struct Candidate* next;
}

int parseInput(char* path){
  struct dirent *DirEntry;
  DIR* directory = opendir(path);
  if(directory == NULL){
    printf("error: no directory stream \n");
    exit(1);
  }

  /* Use for aggregate votes: Check if has subdirectory
  int hasSubDir = 0;
  while((DirEntry = readdir(directory)) != NULL) {
    if(DirEntry->d_name[0] == '.') {  // will include directories begin w/ .*?
      continue;
    }
    if(d->d_type == DT_DIR) {
      hasSubDir = 1;
    }
  }
  */

  char filepath[MAX_FILE_NAME_SIZE];
  strcpy(filepath, path);
  strcat(filepath, "votes.txt");

  FILE* file = file_open(filepath);
  if(file == NULL){
    printf("Not a leaf node. \n");
    return -1;
  }

  struct Candidate** head = NULL;
  struct Candidate* current = *head;
  int candidateExists = 0;
  char candidateVote[1024];
  candidateVote = read_line(candidateVote, file);
  while(candidateVote != NULL) {

    //traverse linked list and check if vote for candidate has already existed.
    current = *head;
    while(current != NULL) {
      if(strcmp(current->name, candidateVote)){
        candidateExists = 1;
        break;
      }
      current = current->next;
    }

    //if candidate already voted for, update its number of votes
    if(candidateExists){
      current->numOfVotes = current->numOfVotes + 1;
    } else {
      //otherwise push it onto linked list
      struct Candidate* newCandidate = (struct Candidate*) malloc(sizeof(struct Candidate));
      newCandidate->numOfVotes = 1;
      strcpy(newCandidate->name, candidateVote);

      //if linked list is empty, push as first one
      if(head == NULL) {
        newCandidate->next = NULL;
        *head = newCandidate;
      } else {
        //if linked list contains something, push to the head of linked list
        newCandidate->next = *head;
        *head = newCandidate;
      }
    }

    candidateVote = read_line(candidateVote,file);

  }

// create output file
char*** strings = (char***) malloc(sizeof(s));
strcpy(filepath,path);
int n = makeargv(path,'/',strings);
char outputName[1024];
outputName = strings[n-1]; // last entry in strings should be current folder name
printf("output name: %s\n",outputName);
strcat(outputName,".txt");
strcat(filepath,outputName);

int fd;
if ((fd = open(filepath,O_CREAT | O_RDWR)) == -1) {
  perror("error opening output file");
  return -1;
}
struct Candidate* current = head;
int buf[1024];
while (current != NULL){
  strcpy(buf,current->name);
  strcat(buf,":");
  strcat(buf,current->numOfVotes)
  if(current->next != NULL) {
    strcat(buf, ",")
  }
  int bytesWritten = write(fd,buf,1024);

}

return 1;

}

int main(int argc, char **argv){
  if(argc != 2){
    printf("Error: Incorrect Usage: %s Program; expected 1 args\n", argv[0]);
		return -1;
  }

  int num = parseInput(argv[1]);
  if(num == -1){
    printf("Error Occurred\n");
  } else {

  }
}
