#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include "util.h"
#include <dirent.h>
#include <sys/wait.h>

typedef struct Candidate {
  char name[1024];
  int numOfVotes;
  struct Candidate* next;
};


int aggregate_votes(char* path){
  DIR *d = opendir(path);
  struct dirent* ent;

  pid_t childpid;
  int subDirs = 0;
  while((ent = readdir(d)) != NULL){
    if(strcmp(ent->d_name,".") == 0 || strcmp(ent->d_name,"..") == 0) {
      continue;
    }

    if(ent->d_type == DT_DIR) {
      subDirs++;
      pid = fork();
      if(pid < 0) {
        // ERROR
      } else if (pid == 0){
        char* pathName = (char*)malloc(1024);
        strcpy(pathName, path);
        strcat(pathName, "/");
        strcat(pathName, ent->d_name);
        aggregate_votes(pathName);
        free(pathName);
      } else {
        while(childpid = waitpid(-1,NULL,0)) {
          if (errno == ECHILD){
            break;
          }
        }
      }
    }

  }

  if(subDirs == 0) { // this is a leaf
      if(execv("Leaf_Counter",path) == -1){
        perror("Leaf exec failure");
      }
    } else {
      DIR *d = opendir(path);
      struct dirent* ent;
      struct Candidate* head = NULL;
      struct Candidate* current = head;
      int candidateExists = 0;

      while((ent = readdir(d)) != NULL){
        // get candidate count from each output file
        char* pathName = (char*)malloc(1024);
        strcat(pathName, "/");
        strcat(pathName, ent->d_name);
        strcat(pathName,"/");
        strcat(pathName, ent->d_name);
        strcat(pathName,".txt");
        int fd = open(pathName, O_RDONLY);

        // split up string into sections of candidate:votes
        char*** strings = (char***) malloc(sizeof(pathName));
        int numstrings = makeargv(path,",",strings);

        for(int i = 0; i < numstrings; i++) { // go through each candidate
          current = head;
          candidateExists = 0;
          char*** candidateStrings = malloc(); // how much space per each candidate entry?
          int entry = makeargv(*strings[i],":",candidateStrings);
          // add data for next candidate
          while(current != NULL) {
            printf("SEGFAULT 3.3\n");
            if(strcmp(current->name, candidateStrings[0][0]) == 0){
              printf("Candidate Exists!\n");
              candidateExists = 1;
              break;
            }
            current = current->next;
          }
          if(candidateExists){
            current->numOfVotes += candidateStrings[0][1];
          } else {
          struct Candidate* newCandidate = (struct Candidate*) malloc(sizeof(struct Candidate));
          strcpy(newCandidate->name, candidateStrings[0][0]);
          newCandidate->numOfVotes = candidateStrings[0][1];
          // append to linked list
          newCandidate->next = head;
          head = newCandidate;
        }
        }
      }
    }
  }

}


int main(int argc, char** argv){
  if(argc != 2){
    printf("Error: got %d args; expected 1 args\n", argc);
    return -1;
  }

}
